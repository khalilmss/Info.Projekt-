package com.crminfo.crminfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrminfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
