package com.crminfo.crminfo.dao;

import com.crminfo.crminfo.entity.KontaktEntry;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KontaktEntryRepository extends JpaRepository<KontaktEntry, Long> {



}
