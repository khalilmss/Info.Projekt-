/*package com.crminfo.crminfo.security;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import java.util.Arrays;

@Configuration
@EnableWebSecurity
public class DemoSecurityConfig {
    @Bean
    public SecurityFilterChain FilterChain(HttpSecurity http) throws Exception {

        return http.build();
    }
//public class DemoSecurityConfig {


    //add support for jdbc... no more hardcoded users :-)

//    @Bean
//    public UserDetailsManager userDetailsManager(DataSource dataSource){
//
//
//        return new JdbcUserDetailsManager(dataSource);
//
//    }

    /*@Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{

        http.authorizeHttpRequests(configurer ->
                                configurer
//                        .requestMatchers("/").hasRole("ADMIN")
//                        .requestMatchers("/employees/toactive").hasRole("ADMIN")
                                        //                     .requestMatchers("/employees/list").hasRole("EMPLOYEE")
//                        .requestMatchers("/").hasRole("EMPLOYEE")
                                        .anyRequest().authenticated()
                )
                .formLogin(form ->
                        form
                                .loginPage("/showMyLoginPage")
                                .loginProcessingUrl("/authenticateTheUser")
                                .permitAll()
                )
                .logout(logout -> logout.permitAll())
                .exceptionHandling(configurer->
                        configurer.accessDeniedPage("/access-denied")
                );


        return http.build();

    }


    /*@Bean
    public InMemoryUserDetailsManager userDetailManager(){

        UserDetails john = User.builder()
                .username("john")
                .password("{noop}test123")
                .roles("EMPLOYEE")
                .build();

        UserDetails mary = User.builder()
                .username("mary")
                .password("{noop}test123")
                .roles("EMPLOYEE", "MANAGER")
                .build();


        UserDetails susan = User.builder()
                .username("susan")
                .password("{noop}test123")
                .roles("EMPLOYEE", "MANAGER1", "ADMIN")
                .build();

        UserDetails sam = User.builder()
                .username("sam")
                .password("{noop}test123")
                .roles("EMPLOYEE", "MANAGER2", "ADMIN")
                .build();


      //  UserDetails khalil = User.builder()
                .username("khalil")
                .password("{noop}khalil")
                .roles("ADMIN", "EMPLOYEE")
                .build();

        UserDetails hicham = User.builder()
                .username("hicham")
                .password("{noop}hicham")
                .roles("ADMIN", "EMPLOYEE")
                .build();
        UserDetails ahmed = User.builder()
                .username("ahmed")
                .password("{noop}ahmed")
                .roles("EMPLOYEE")
                .build();

        UserDetails lamiaa = User.builder()
                .username("lamiaa")
                .password("{noop}lamiaa")
                .roles("EMPLOYEE")
                .build();

        return new InMemoryUserDetailsManager(john, mary, susan, sam, khalil, lamiaa, hicham, ahmed);
    } */



    // Define your user details service bean here
    // You might want to replace this with a custom implementation
  /* @Bean
    public UserDetailsService userDetailsService() {
        // Example in-memory user details
        // Replace this with your user details service
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        manager.createUser(User.withUsername("user")
                .password(new BCryptPasswordEncoder().encode("password"))
                .roles("USER").build());
        return manager;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        HttpSecurity disable = http
                .authorizeRequests(authorizeRequests ->
                        authorizeRequests
                                .anyRequest().permitAll()  // Allow all requests without authentication
                )
                .csrf().disable();// Disable CSRF protection for simplicity

        return http.build();

    }

    // Configure CORS if needed

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("*")); // Allows all origins
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE"));
        configuration.setAllowedHeaders(Arrays.asList("Content-Type", "Authorization"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
    

    } */
package com.crminfo.crminfo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.cors.CorsConfigurationSource;

import java.util.Arrays;

@Configuration
@EnableWebSecurity
public class DemoSecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                // Disable CSRF for simplicity, consider enabling it for production
                .csrf().disable()

                // Permit all requests without authentication
                .authorizeRequests().anyRequest().permitAll()

                // Enable CORS with configuration
                .and().cors().configurationSource(corsConfigurationSource());

        return http.build();
    }
   /* @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .and()
                .httpBasic();
        return http.build();
    }*/

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("*")); // Allow all origins for development
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS")); // Allow standard methods
        configuration.setAllowedHeaders(Arrays.asList("Content-Type", "Authorization")); // Allow headers like Content-Type and Authorization

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration); // Apply configuration to all paths
        return source;
    }
   /* @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        manager.createUser(User.withDefaultPasswordEncoder()
                .username("Ahmed")
                .password("123456")
                .roles("USER")
                .build());
        manager.createUser(User.withDefaultPasswordEncoder()
                .username("Khalil")
                .password("123456")
                .roles("USER")
                .build());
        // Add more users as needed
        return manager;
    }*/
}


