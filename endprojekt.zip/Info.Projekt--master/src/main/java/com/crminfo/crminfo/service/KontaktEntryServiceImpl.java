package com.crminfo.crminfo.service;
import com.crminfo.crminfo.entity.KontaktEntry;
import com.crminfo.crminfo.dao.KundeRepository;
import com.crminfo.crminfo.dao.KontaktEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class KontaktEntryServiceImpl implements KontaktEntryService {

    private final KontaktEntryRepository kontaktEntryRepository;
    private final KundeRepository KundeRepository;

    @Autowired
    public KontaktEntryServiceImpl(KontaktEntryRepository kontaktEntryRepository, com.crminfo.crminfo.dao.KundeRepository kundeRepository) {
        this.kontaktEntryRepository = kontaktEntryRepository;
        this.KundeRepository = kundeRepository;
    }

    @Override
    public List<KontaktEntry> findAll() {
        return kontaktEntryRepository.findAll();
    }

    @Override
    public KontaktEntry save(KontaktEntry kontaktEntry) {
        return kontaktEntryRepository.save(kontaktEntry);
    }



    @Override
    public boolean existsById(Long id) {
        return  kontaktEntryRepository.existsById(id);
    }
    public boolean checkKundeExistsInFiliale(String name, String vorname, Long filialeId) {
        // Correctly use the instance of kundeRepository to call the method
        return KundeRepository.existsByNameAndVornameAndFilialeId(name, vorname, filialeId);
    }

    // Implement other methods as necessary
}