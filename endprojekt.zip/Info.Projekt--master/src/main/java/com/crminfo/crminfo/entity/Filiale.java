package com.crminfo.crminfo.entity;

import jakarta.persistence.*;
@Entity
@Table(name = "filiale")
public class Filiale {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bezirk_id", nullable = false)
    private Bezirk bezirk;

    // Constructors, Getters and Setters
}
