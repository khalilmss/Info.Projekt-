package com.crminfo.crminfo.dao;
import com.crminfo.crminfo.entity.Bezirk;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BezirkRepository extends JpaRepository<Bezirk, Long> {
    // Custom query methods if needed
}

