package com.crminfo.crminfo.service;

import com.crminfo.crminfo.entity.Kunde;

import java.util.List;

public interface KundeService {


    List<Kunde> findAll();

    //Kunden findById(Long theId);

    Kunde findById(Long theId);

    Kunde save(Kunde thekunden);

    //void deleteById(Long theId);
    //void savek (Kunden thekunden);
    List<Kunde> findKundenByFiliale(Long filialeId);

    void deleteById(Long theId);

    Kunde saveOrUpdateKunde(Kunde kunde);

    boolean emailExists(String email);
    public void setEmailSentForBirthday(Long id, boolean sentStatus);

    //Kunde findKundenAndCommentByKundenId(int theId);


}
