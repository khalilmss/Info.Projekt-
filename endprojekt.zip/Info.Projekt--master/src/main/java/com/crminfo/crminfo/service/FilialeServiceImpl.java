package com.crminfo.crminfo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crminfo.crminfo.dao.FilialeRepository;
import com.crminfo.crminfo.entity.Filiale;
import java.util.List;

@Service
public class FilialeServiceImpl implements FilialeService {

    private final FilialeRepository filialeRepository;

    @Autowired
    public FilialeServiceImpl(FilialeRepository filialeRepository) {
        this.filialeRepository = filialeRepository;
    }

    @Override
    public List<Filiale> findAll() {
        return filialeRepository.findAll();
    }

    @Override
    public Filiale findById(Long id) {
        return filialeRepository.findById(id).orElse(null);
    }

    @Override
    public Filiale save(Filiale filiale) {
        return filialeRepository.save(filiale);
    }

    @Override
    public void deleteById(Long id) {
        filialeRepository.deleteById(id);
    }


    @Override
    public List<Filiale> findByBezirkId(Long bezirkId) {
        return filialeRepository.findByBezirkId(bezirkId);
    }

}

