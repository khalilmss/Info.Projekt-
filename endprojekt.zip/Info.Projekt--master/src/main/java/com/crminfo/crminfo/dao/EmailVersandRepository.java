package com.crminfo.crminfo.dao;

import com.crminfo.crminfo.entity.EmailVersand;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmailVersandRepository extends JpaRepository<EmailVersand , Long> {


}
