package com.crminfo.crminfo.dto;
public class KundeInFilialeCheckRequest {

    private String name;
    private String vorname;
    private Long filialeId;


    // Constructor
    public KundeInFilialeCheckRequest() {}

    // Getters
    public String getName() {
        return name;
    }

    public String getVorname() {
        return vorname;
    }

    public Long getFilialeId() {
        return filialeId;
    }


    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public void setFilialeId(Long filialeId) {
        this.filialeId = filialeId;
    }



}

