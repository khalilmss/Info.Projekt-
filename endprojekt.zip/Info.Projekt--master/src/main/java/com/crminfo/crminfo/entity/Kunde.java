package com.crminfo.crminfo.entity;


import jakarta.persistence.*;


import java.time.LocalDate;
import java.util.Objects;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Table(name = "kunde")
public class Kunde {

    //@ManyToOne
    //@JoinColumn
    @JoinColumn(name = "bezirk_id")
    private Long bezirkeId;
            @JoinColumn(name = "filiale_id")
    private Long filialeId;

    @jakarta.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;
    @Column(name = "geschlecht")
    private String geschlecht;
    @Column(name = "Titel")
    private String titel;
    @Column(name = "Name")
    private String name;
    @Column(name = "Geburtsname")
    private String geburtsname;

    //@Column(name = "Vorname")
    private String vorname;

    @Column(name = "Strasse")
    private String strasse;

    @Column(name = "PLZ")
    private String plz;

    @Column(name = "ORT")
    private String ort;


    @Column(name ="Geburtsdatum" )
    private LocalDate geburtsdatum;

    @Column(name = "Land")
    private String land;

    @Column(name = "Staatsangehorigkeit")
    private String staatsangehorigkeit;


    @Column(name = "Email")
    private String email;


    @Column(name = "familienstatus")
    private String familienstatus;

    @Column(name = "berufsgruppe")
    private String berufsgruppe;

    @Column(name = "selbststandig")
    private String selbststandig;

    @Column(name ="selbstandingseit" )
    private LocalDate selbstandingseit;

    @Column(name = "branche")
    private String branche;

    @Column(name = "netto" )
    private String netto;

    @Column(name = "AnzahlderKinde" )
    private String anzahlderKinde;

    @Column(name = "wohnart")
    private String wohnart;
    @Column(name = "produkte")
    private String produkte;

    @Column(name= "NummerTyp" )
    private String nummerTyp;

    @Column(name = "nummer")
    private String nummer;


    @Column(name = "kundenStatus" )
    private String kundenStatus;

    @Column(name = "kontonummer")
    private String kontonummer;
    @Column(name = "kundennummer")
    private String kundennummer;

    private boolean einverstandenWerbungPerEmail;
    private boolean einverstandenUebermittlungAnSchufa;
    private boolean emailSentForBirthday;



    public Kunde(Long bezirkeId,Long filialeId, Long id, String geschlecht, String titel, String name, String geburtsname, String vorname, String strasse, String plz, String ort, LocalDate geburtsdatum, String land, String staatsangehorigkeit, String email, String familienstatus, String berufsgruppe, String selbststandig, LocalDate selbstandingseit, String branche, String netto, String anzahlderKinde, String wohnart, String produkte,String nummerTyp ,String nummer, String kundenStatus, String kontonummer, String kundennummer, boolean einverstandenWerbungPerEmail, boolean einverstandenUebermittlungAnSchufa,boolean emailSentForBirthday) {
        this.bezirkeId = bezirkeId;
        this.filialeId = filialeId;
        this.id = id;
        this.geschlecht = geschlecht;
        this.titel = titel;
        this.name = name;
        this.geburtsname = geburtsname;
        this.vorname = vorname;
        this.strasse = strasse;
        this.plz = plz;
        this.ort = ort;
        this.geburtsdatum = geburtsdatum;
        this.land = land;
        this.staatsangehorigkeit = staatsangehorigkeit;
        this.email = email;
        this.familienstatus = familienstatus;
        this.berufsgruppe = berufsgruppe;
        this.selbststandig = selbststandig;
        this.selbstandingseit = selbstandingseit;
        this.branche = branche;
        this.netto = netto;
        this.anzahlderKinde = anzahlderKinde;
        this.wohnart = wohnart;
        this.produkte = produkte;
        this.nummerTyp =nummerTyp;
        this.nummer = nummer;
        this.kundenStatus = kundenStatus;
        this.kontonummer = kontonummer;
        this.kundennummer = kundennummer;
        this.einverstandenWerbungPerEmail = einverstandenWerbungPerEmail;
        this.einverstandenUebermittlungAnSchufa = einverstandenUebermittlungAnSchufa;
        this.emailSentForBirthday= emailSentForBirthday;

    }
    public Long getBezirkId() {
        return bezirkeId;
    }

    public void setBezirkId(Long bezirkeIdId) {
        this.bezirkeId = bezirkeIdId;
    }

    public Long getFilialeId() {
        return filialeId;
    }

    public void setFilialeId(Long filialeId) {
        this.filialeId = filialeId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getGeschlecht() {
        return geschlecht;
    }

    public void setGeschlecht(String geschlecht) {
        this.geschlecht = geschlecht;
    }

    public String getTitel() {
        return titel;
    }

    public void setTitel(String titel) {
        this.titel = titel;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGeburtsname() {
        return geburtsname;
    }

    public void setGeburtsname(String geburtsname) {
        this.geburtsname = geburtsname;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public String getStrasse() {
        return strasse;
    }

    public void setStrasse(String strasse) {
        this.strasse = strasse;
    }

    public String getPlz() {
        return plz;
    }

    public void setPlz(String plz) {
        this.plz = plz;
    }

    public String getOrt() {
        return ort;
    }

    public void setOrt(String ort) {
        this.ort = ort;
    }

    public LocalDate getGeburtsdatum() {
        return geburtsdatum;
    }

    public void setGeburtsdatum(LocalDate geburtsdatum) {
        this.geburtsdatum = geburtsdatum;
    }

    public String getLand() {
        return land;
    }

    public void setLand(String land) {
        this.land = land;
    }

    public String getStaatsangehorigkeit() {
        return staatsangehorigkeit;
    }

    public void setStaatsangehorigkeit(String staatsangehorigkeit) {
        this.staatsangehorigkeit = staatsangehorigkeit;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFamilienstatus() {
        return familienstatus;
    }

    public void setFamilienstatus(String familienstatus) {
        this.familienstatus = familienstatus;
    }

    public String getBerufsgruppe() {
        return berufsgruppe;
    }

    public void setBerufsgruppe(String berufsgruppe) {
        this.berufsgruppe = berufsgruppe;
    }

    public String getSelbststandig() {
        return selbststandig;
    }

    public void setSelbststandig(String selbststandig) {
        this.selbststandig = selbststandig;
    }

    public LocalDate getSelbstandingseit() {
        return selbstandingseit;
    }

    public void setSelbstandingseit(LocalDate selbstandingseit) {
        this.selbstandingseit = selbstandingseit;
    }

    public String getBranche() {
        return branche;
    }

    public void setBranche(String branche) {
        this.branche = branche;
    }

    public String getNetto() {
        return netto;
    }

    public void setNetto(String netto) {
        this.netto = netto;
    }

    public String getAnzahlderKinde() {
        return anzahlderKinde;
    }

    public void setAnzahlderKinde(String anzahlderKinde) {
        this.anzahlderKinde = anzahlderKinde;
    }

    public String getWohnart() {
        return wohnart;
    }

    public void setWohnart(String wohnart) {
        this.wohnart = wohnart;
    }

    public String getProdukte() {
        return produkte;
    }

    public void setProdukte(String produkte) {
        this.produkte = produkte;
    }
    public String getNummerTyp() {
        return nummerTyp;
    }

    public void setNummerTyp(String nummerTyp) {
        this.nummerTyp = nummerTyp;
    }

    public String getNummer() {
        return nummer;
    }

    public void setNummer(String nummer) {
        this.nummer = nummer;
    }

    public String getKundenStatus() {
        return kundenStatus;
    }

    public void setKundenStatus(String kundenStatus) {
        this.kundenStatus = kundenStatus;
    }

    public String getKontonummer() {
        return kontonummer;
    }

    public void setKontonummer(String kontonummer) {
        this.kontonummer = kontonummer;
    }

    public String getKundennummer() {
        return kundennummer;
    }

    public void setKundennummer(String kundennummer) {
        this.kundennummer = kundennummer;
    }

    public boolean isEinverstandenWerbungPerEmail() {
        return einverstandenWerbungPerEmail;
    }

    public void setEinverstandenWerbungPerEmail(boolean einverstandenWerbungPerEmail) {
        this.einverstandenWerbungPerEmail = einverstandenWerbungPerEmail;
    }

    public boolean isEinverstandenUebermittlungAnSchufa() {
        return einverstandenUebermittlungAnSchufa;
    }

    public void setEinverstandenUebermittlungAnSchufa(boolean einverstandenUebermittlungAnSchufa) {
        this.einverstandenUebermittlungAnSchufa = einverstandenUebermittlungAnSchufa;
    }

    public boolean isEmailSentForBirthday() {
        return emailSentForBirthday;
    }

    public void setEmailSentForBirthday(boolean emailSentForBirthday) {
        this.emailSentForBirthday = emailSentForBirthday;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Kunde kunde = (Kunde) o;
        return id.equals(kunde.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Kunde{" +
                "bezirkId=" + bezirkeId +
                "filialeId=" + filialeId +
                ", id=" + id +
                ", geschlecht='" + geschlecht + '\'' +
                ", titel='" + titel + '\'' +
                ", name='" + name + '\'' +
                ", geburtsname='" + geburtsname + '\'' +
                ", vorname='" + vorname + '\'' +
                ", strasse='" + strasse + '\'' +
                ", plz='" + plz + '\'' +
                ", ort='" + ort + '\'' +
                ", geburtsdatum=" + geburtsdatum +
                ", land='" + land + '\'' +
                ", staatsangehorigkeit='" + staatsangehorigkeit + '\'' +
                ", email='" + email + '\'' +
                ", familienstatus='" + familienstatus + '\'' +
                ", berufsgruppe='" + berufsgruppe + '\'' +
                ", selbststandig='" + selbststandig + '\'' +
                ", selbstandingseit=" + selbstandingseit +
                ", branche='" + branche + '\'' +
                ", netto='" + netto + '\'' +
                ", anzahlderKinde='" + anzahlderKinde + '\'' +
                ", wohnart='" + wohnart + '\'' +
                ", produkte='" + produkte + '\'' +
                ", nummerTyp='" + nummerTyp + '\'' +
                ", nummer='" + nummer + '\'' +
                ", kundenStatus='" + kundenStatus + '\'' +
                ", kontonummer='" + kontonummer + '\'' +
                ", kundennummer='" + kundennummer + '\'' +
                ", einverstandenWerbungPerEmail=" + einverstandenWerbungPerEmail +
                ", einverstandenUebermittlungAnSchufa=" + einverstandenUebermittlungAnSchufa +
                ", emailSentForBirthday="+ emailSentForBirthday+

                '}';
    }
}