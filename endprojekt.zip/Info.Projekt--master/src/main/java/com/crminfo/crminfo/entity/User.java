package com.crminfo.crminfo.entity;


import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
//import jakarta.persistence.Temporal;
//import jakarta.persistence.TemporalType;

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String admin;
    private String username;
    private String password;
    private String status;
    private String passwortStatus;
    private int counter;
    private String passwort2;
    private String passwort3;
    private String passwort4;
    private String passwort5;
    private String passwort6;





    public int getCounter() {
        return counter;
    }


    public void setCounter(int counter) {
        this.counter = counter;
    }


    public String getPasswort2() {
        return passwort2;
    }


    public void setPasswort2(String passwort2) {
        this.passwort2 = passwort2;
    }





    public String getPasswort3() {
        return passwort3;
    }


    public void setPasswort3(String passwort3) {
        this.passwort3 = passwort3;
    }


    public String getPasswort4() {
        return passwort4;
    }


    public void setPasswort4(String passwort4) {
        this.passwort4 = passwort4;
    }


    public String getPasswort5() {
        return passwort5;
    }


    public void setPasswort5(String passwort5) {
        this.passwort5 = passwort5;
    }


    public String getPasswort6() {
        return passwort6;
    }


    public void setPasswort6(String passwort6) {
        this.passwort6 = passwort6;
    }


    public String getPasswortStatus() {
        return passwortStatus;
    }


    public void setPasswortStatus(String passwortStatus) {
        this.passwortStatus = passwortStatus;
    }

    //@Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "edatum")
    private LocalDateTime edatum;

    //@Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "adatum")
    private LocalDateTime adatum;

    public User() {
        //this.creationDate = LocalDateTime.now();
        //this.expirationDate = LocalDateTime.now().plusMonths(3);
        this.edatum = null;
        this.adatum =null;
    }


    public LocalDateTime getEdatum() {
        return edatum;
    }
    public void setEdatum(LocalDateTime edatum) {
        this.edatum = edatum;
    }


    public LocalDateTime getAdatum() {
        return adatum;
    }

    public void setAdatum(LocalDateTime adatum) {
        this.adatum = adatum;
    }


    public User(
            String name,
            String email,
            String admin,
            String username,
            String password,
            String status,
            LocalDateTime edatum,
            LocalDateTime adatum,
            int counter,
            String passwort2,
            String passwort3,
            String passwort4,
            String passwort5,
            String passwort6
    ) {
        this.name = name;
        this.email = email;
        this.admin = admin;
        this.username = username;
        this.password = password;
        this.status = status;
        this.edatum = edatum;
        this.adatum = adatum;
        this.counter=counter;
        this.passwort2=passwort2;
        this.passwort3=passwort3;
        this.passwort4=passwort4;
        this.passwort5=passwort5;
        this.passwort6=passwort6;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAdmin() {
        return admin;
    }
    public void setAdmin(String admin) {
        this.admin = admin;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }



    @Override
    public String toString() {
        return "User [id=" + id + ", name=" + name + ", email=" + email + ", admin=" + admin + ", username=" + username
                + ", password=" + password + ", status=" + status + ", passwortStatus=" + passwortStatus + ", counter="
                + counter + ", passwort2=" + passwort2 + ", passwort3=" + passwort3 + ", passwort4=" + passwort4
                + ", passwort5=" + passwort5 + ", passwort6=" + passwort6 + ", edatum=" + edatum + ", adatum=" + adatum
                + "]";
    }


    public User(Long id) {
        super();
        this.id = id;
    }

}

