package com.crminfo.crminfo.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import com.crminfo.crminfo.entity.Filiale;

@Repository
public interface FilialeRepository extends JpaRepository<Filiale, Long> {
    List<Filiale> findByBezirkId(Long bezirkId);
}