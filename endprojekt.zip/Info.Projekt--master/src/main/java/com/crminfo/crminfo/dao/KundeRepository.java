package com.crminfo.crminfo.dao;

import com.crminfo.crminfo.entity.Kunde;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface KundeRepository extends JpaRepository<Kunde, Long> {

    List<Kunde> findByFilialeId(Long filialeId);


    public  boolean existsByNameAndVornameAndFilialeId(String name, String vorname, Long filialeId);
    boolean existsByNameAndVornameAndEmail(String name, String vorname,String email);

    boolean existsByEmail(String email);
}
