package com.crminfo.crminfo.service;

import com.crminfo.crminfo.dao.EmailVersandRepository;
import com.crminfo.crminfo.dao.KundeRepository;
import com.crminfo.crminfo.entity.EmailVersand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EmailVersandServiceImpl implements EmailVersandService {

    private final KundeRepository kundeRepository;
    private final EmailVersandRepository emailVersandRepository;

    @Autowired
    public EmailVersandServiceImpl(KundeRepository kundeRepository, EmailVersandRepository emailVersandRepository) {
        this.kundeRepository = kundeRepository;
        this.emailVersandRepository = emailVersandRepository;
    }

    @Override
    public boolean checkKundeExists(String name, String vorname,String email) {
        // Check if a Kunde exists with the provided name and vorname
        boolean kundeExists = kundeRepository.existsByNameAndVornameAndEmail(name, vorname, email);

        if (kundeExists) {
            // Proceed with the email logic as the correct customer has been identified
            return true;
        }

        return false; // Kunde not found
    }
    @Override
    public List<EmailVersand> findAllEmails() {
        return emailVersandRepository.findAll();
    }

    @Override
    public EmailVersand save(EmailVersand emailVersand) {
        return emailVersandRepository.save(emailVersand);
    }
}





