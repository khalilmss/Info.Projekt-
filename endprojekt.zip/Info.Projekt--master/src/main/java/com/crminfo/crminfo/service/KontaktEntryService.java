package com.crminfo.crminfo.service;

import com.crminfo.crminfo.entity.KontaktEntry;
import java.util.List;

public interface KontaktEntryService {
    List<KontaktEntry> findAll();
    KontaktEntry save(KontaktEntry kontaktEntry);
    boolean existsById(Long id);

    public boolean checkKundeExistsInFiliale(String name, String vorname, Long filialeId);

    // Define other necessary operations like delete, findById, etc.
}