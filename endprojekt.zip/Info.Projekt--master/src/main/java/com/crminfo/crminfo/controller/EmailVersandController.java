package com.crminfo.crminfo.controller;

import com.crminfo.crminfo.entity.EmailVersand;
import com.crminfo.crminfo.service.EmailVersandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/emailversand")
public class EmailVersandController {

    private final EmailVersandService emailVersandService;

    @Autowired
    public EmailVersandController(EmailVersandService emailVersandService) {
        this.emailVersandService = emailVersandService;
    }

    @PostMapping("/check-kunde")
    public ResponseEntity<?> checkKunde(@RequestBody EmailVersand emailVersand) {
        boolean kundeExists = emailVersandService.checkKundeExists(
                emailVersand.getKundeName(), emailVersand.getKundeVorname(),emailVersand.getEmail());

        if (kundeExists) {
            return ResponseEntity.ok(Map.of("exists", true));
        } else {
            return ResponseEntity.badRequest().body(Map.of("exists", false, "message", "Kunde nicht gefunden"));
        }
    }

    @GetMapping
    public ResponseEntity<List<EmailVersand>> getAllEmails() {
        List<EmailVersand> emails = emailVersandService.findAllEmails();
        return ResponseEntity.ok(emails);
    }
    @PostMapping
    public ResponseEntity<?> createEmailVersand(@RequestBody EmailVersand emailVersand) {
        boolean kundeExists = emailVersandService.checkKundeExists(emailVersand.getKundeName(), emailVersand.getKundeVorname(),emailVersand.getEmail());

        if (kundeExists) {
            EmailVersand savedEmail = emailVersandService.save(emailVersand);
            return ResponseEntity.ok(savedEmail);
        } else {
            return ResponseEntity.badRequest().body(Map.of("message", "Kunde nicht gefunden, Email wurde nicht versand"));
        }
    }
    @PostMapping("/save-email")
    public ResponseEntity<?> saveEmail(@RequestBody EmailVersand emailVersand) {
        EmailVersand savedEmail = emailVersandService.save(emailVersand);
        if (savedEmail != null) {
            return ResponseEntity.ok().body("Email has been sent and saved successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error saving the email.");
        }
    }
    // If needed, implement other endpoints for EmailVersand management
}

