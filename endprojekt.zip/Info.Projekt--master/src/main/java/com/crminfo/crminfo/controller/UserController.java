package com.crminfo.crminfo.controller;




import java.util.List;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.Optional;

import com.crminfo.crminfo.dao.UserRepository;
import com.crminfo.crminfo.entity.User;
import com.crminfo.crminfo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashSet;
import java.util.Set;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@RestController
@RequestMapping("/api")
public class UserController {

    private final UserRepository userRepository;
    private final UserService userService;

    private Set<String> existingUsernames = new HashSet<>();
    private Set<String> existingEmails = new HashSet<>();


    @Autowired
    public UserController(UserRepository userRepository, UserService userService) {
        this.userRepository = userRepository;
        this.userService = userService;
    }

    //@Autowired
    //private BCryptPasswordEncoder passwordEncoder;
    // private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();


    private static String hashString(String input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedHash = digest.digest(input.getBytes(StandardCharsets.UTF_8));

        //Konvertieren Sie das Byte-Array in eine hexadezimale Darstellung
        StringBuilder hexStringBuilder = new StringBuilder();
        for (byte b : encodedHash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexStringBuilder.append('0');
            }
            hexStringBuilder.append(hex);
        }

        return hexStringBuilder.toString();
    }


    @CrossOrigin
    @PostMapping("/createUser")
    public ResponseEntity<String> createUser(@RequestBody User userDto) {

        existingUsernames.clear();
        existingEmails.clear();

        userRepository.findAll().forEach(user -> {
            existingUsernames.add(user.getUsername());
            existingEmails.add(user.getEmail());
        });


        try {

            if (existingUsernames.contains(userDto.getUsername())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Benutzername bereits existiert ");
            }


            if (existingEmails.contains(userDto.getEmail())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email bereits existiert");
            }



            User user = new User();
            user.setName(userDto.getName());
            user.setEmail(userDto.getEmail());
            user.setAdmin(userDto.getAdmin());
            user.setUsername(userDto.getUsername());
            user.setCounter(0);

            user.setPassword(userDto.getPassword());
            //user.setPassword(ps.encode(userDto.getPassword()));
            //String str=hashString(userDto.getPassword());
            //user.setPassword(str);
            user.setStatus(userDto.getStatus());
            user.setPasswortStatus(userDto.getPasswortStatus());


            userRepository.save(user);


            //existingUsernames.add(user.getUsername());
            //existingEmails.add(user.getEmail());

            return ResponseEntity.ok("Benutzer wird  erfolgreich erstellt");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Fehler beim Erstellen des Benutzers " + e.getMessage());
        }
    }



    @CrossOrigin
    @GetMapping("/getallusers")
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }




    @CrossOrigin
    @PostMapping("/{userId}/updateStatus")
    public ResponseEntity<String> updateUserStatus(
            @PathVariable Long userId,
            @RequestParam String newStatus) {

        try {
            userService.updateUserStatus(userId,newStatus);
            return ResponseEntity.ok("Benutzerstatus erfolgreich aktualisiert");


        }catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fehler beim Aktualisieren des Status");
        }
    }

    @CrossOrigin
    @PostMapping("/{userId}/reject")
    public ResponseEntity<String> rejectUserStatus(
            @PathVariable Long userId,
            @RequestParam String newStatus) {

        try {
            userService.rejectUserStatus(userId,newStatus);
            return ResponseEntity.ok("Benutzerstatus erfolgreich aktualisiert");


        }catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fehler beim Aktualisieren des Status");
        }
    }

    @CrossOrigin
    @PostMapping("/{userId}/updateStatus2")
    public ResponseEntity<String> updateUserStatus2(
            @PathVariable Long userId,
            @RequestParam String newStatus) {

        try {
            userService.updateUserStatus2(userId, "Loeschung ausstehend");
            return ResponseEntity.ok("Benutzerstatus erfolgreich aktualisierty");


        }catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fehler beim Aktualisieren des Status");
        }
    }

    @CrossOrigin
    @PostMapping("/{userId}/updateStatus3")
    public ResponseEntity<String> updateUserStatus3(
            @PathVariable Long userId,
            @RequestParam String newStatus) {

        try {
            userService.updateUserStatus3(userId, "Loeschung ausstehend");
            return ResponseEntity.ok("Benutzerstatus erfolgreich aktualisiert");


        }catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fehler beim Aktualisieren des Status");
        }
    }
    @CrossOrigin
    @DeleteMapping("/{id}/deleteUser")
    public ResponseEntity<String> updateUserStatus3(
            @PathVariable Long id) {

        try {
            userService.deleteUser(id);

            return ResponseEntity.ok("Benutzerstatus erfolgreich aktualisiert");



        }catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Fehler beim Aktualisieren des Status");
        }
    }
    @CrossOrigin
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Map<String, String> credentials) throws NoSuchAlgorithmException {
        String username = credentials.get("username");
        String password = credentials.get("password");
        String hashedPassword=hashString(password);

        Optional<User> user = userService.authenticateUser1(username,password);
        Optional<User> optionalUser = userService.authenticateUser2(username);
        Optional<User> user1 = userService.authenticateUser1(username,hashedPassword);
        Optional<User> user2 = userService.authenticateUser3(username,hashedPassword);
        Optional<User> user3 = userService.authenticateUser4(username,hashedPassword);
        Optional<User> user4 = userService.authenticateUser5(username,hashedPassword);
        Optional<User> user5 = userService.authenticateUser6(username,hashedPassword);
        Optional<User> user6 = userService.authenticateUser7(username,hashedPassword);




        if (user.isPresent() && "aktiv".equalsIgnoreCase(user.get().getStatus()) && "initialPasswort".equalsIgnoreCase(user.get().getPasswortStatus()) ) {
            // Authentication successful
            return ResponseEntity.ok("initialPasswort");


        }else if (optionalUser.isPresent() && "aktiv".equalsIgnoreCase(optionalUser.get().getStatus()) && "neuPasswort".equalsIgnoreCase(optionalUser.get().getPasswortStatus()) ) {
            int counter=optionalUser.get().getCounter();
            LocalDateTime currentTime = LocalDateTime.now();
            long timeDifference = ChronoUnit.DAYS.between(currentTime, optionalUser.get().getAdatum());



            if(counter==1){
                if (user1.isPresent()) {
                    if(currentTime.isAfter(optionalUser.get().getAdatum())){
                        return ResponseEntity.ok("Passwortablauf");

                    }else if(timeDifference==10) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 10 Tage gültig");

                    }else if (timeDifference==5) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 5 Tage gültig");

                    }else if (timeDifference==2) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 2 Tage gültig");

                    }else {return ResponseEntity.ok("kundebetreuer");}



                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig passwort");}

            }else  if(counter==2){
                if (user2.isPresent()) {
                    if(currentTime.isAfter(optionalUser.get().getAdatum())){
                        return ResponseEntity.ok("Passwortablauf");

                    }else if(timeDifference==10) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 10 Tage gültig");

                    }else if (timeDifference==5) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 5 Tage gültig");

                    }else if (timeDifference==2) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 2 Tage gültig");

                    }else {return ResponseEntity.ok("kundebetreuer"+timeDifference);}



                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig passwort");}
            }else if(counter==3){
                if (user3.isPresent()) {
                    if(currentTime.isAfter(optionalUser.get().getAdatum())){
                        return ResponseEntity.ok("Passwortablauf");

                    }else if(timeDifference==10) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 10 Tage gültig");

                    }else if (timeDifference==5) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 5 Tage gültig");

                    }else if (timeDifference==2) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 2 Tage gültig");

                    }else {return ResponseEntity.ok("kundebetreuer");}



                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig passwort");}
            }else if(counter==4){
                if (user4.isPresent()) {
                    if(currentTime.isAfter(optionalUser.get().getAdatum())){
                        return ResponseEntity.ok("Passwortablauf");

                    }else if(timeDifference==10) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 10 Tage gültig");

                    }else if (timeDifference==5) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 5 Tage gültig");

                    }else if (timeDifference==2) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 2 Tage gültig");

                    }else {return ResponseEntity.ok("kundebetreuer");}



                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig passwort");}

            }else if(counter==5){
                if (user5.isPresent()) {
                    if(currentTime.isAfter(optionalUser.get().getAdatum())){
                        return ResponseEntity.ok("Passwortablauf");

                    }else if(timeDifference==10) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 10 Tage gültig");

                    }else if (timeDifference==5) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 5 Tage gültig");

                    }else if (timeDifference==2) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 2 Tage gültig");

                    }else {return ResponseEntity.ok("kundebetreuer");}



                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig passwort");}
            }else {
                if (user6.isPresent()) {
                    if(currentTime.isAfter(optionalUser.get().getAdatum())){
                        return ResponseEntity.ok("Passwortablauf");

                    }else if(timeDifference==10) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 10 Tage gültig");

                    }else if (timeDifference==5) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 5 Tage gültig");

                    }else if (timeDifference==2) {
                        return ResponseEntity.ok("Ihr Passwort bleibt für die nächsten 2 Tage gültig");

                    }else {return ResponseEntity.ok("kundebetreuer");}



                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig passwort");}}


        }else {
            //Authentifizierung fehlgeschlagen
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig Benutzername oder Passwort");
        }


    }




    //Am Anfang, wenn der Kundenbetreuer sich mit dem Initialpasswort anmeldet, muss erneut ein neues Passwort eingegeben werden
    @CrossOrigin
    @PostMapping("/updatePassword")
    public ResponseEntity<String> updatePassword(@RequestBody Map<String, String> credentials) throws NoSuchAlgorithmException {
        String username = credentials.get("username");
        String newPassword = credentials.get("password");

        String str=hashString(newPassword);

        Optional<User> optionalUser = userService.authenticateUser2(username);

        if (optionalUser.isPresent()) {

            User user = optionalUser.get();
            user.setPassword(str);
            user.setPasswortStatus("neuPasswort");
            user.setCounter(1);
            user.setEdatum(LocalDateTime.now());
            user.setAdatum(LocalDateTime.now().plusMonths(3));
            userRepository.save(user);

            return ResponseEntity.ok("update erfolgreich");

        } else {
            //Authentifizierung fehlgeschlagen
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig Benutzername oder passwort");
        }
    }


    //Hier, wenn der Kundenbetreuer sein Passwort ändern möchte
    @CrossOrigin
    @PostMapping("/updatePassword1")
    public ResponseEntity<String> updatePassword1(@RequestBody Map<String, String> credentials) throws NoSuchAlgorithmException {
        String username = credentials.get("username");
        String oldPassword = credentials.get("oldPassword");
        String newPassword = credentials.get("newPassword");

        String str=hashString(newPassword);
        String str1=hashString(oldPassword);
        Optional<User> optionalUser = userService.authenticateUser2(username);


        if(optionalUser.isPresent())
        {
            User user = optionalUser.get();
            int counter=user.getCounter();


            if(counter==1)
            {

                if(user.getPassword().equals(str1))
                {
                    if(str.equals(user.getPassword()) || str.equals(user.getPasswort2()) || str.equals(user.getPasswort3())|| str.equals(user.getPasswort4())|| str.equals(user.getPasswort5())|| str.equals(user.getPasswort6()))
                    {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Verwenden Sie nicht die gleichen letzten sechs Passwörter.");


                    }
                    else {
                        user.setPasswort2(str);
                        user.setCounter(2);
                        user.setEdatum(LocalDateTime.now());
                        user.setAdatum(LocalDateTime.now().plusMonths(3));
                        userRepository.save(user);

                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Passwort wurde erfolgreich geändert");

                    }

                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Falsches altes Passwort");
                }


            }else if(counter==2) {
                if(user.getPasswort2().equals(str1))
                {
                    if(str.equals(user.getPassword()) || str.equals(user.getPasswort2()) || str.equals(user.getPasswort3())|| str.equals(user.getPasswort4())|| str.equals(user.getPasswort5())|| str.equals(user.getPasswort6()))
                    {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Verwenden Sie nicht die gleichen letzten sechs Passwörter.");
                    }

                    else {
                        user.setPasswort3(str);
                        user.setCounter(3);
                        user.setEdatum(LocalDateTime.now());
                        user.setAdatum(LocalDateTime.now().plusMonths(3));
                        userRepository.save(user);

                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Passwort wurde erfolgreich geändert");
                    }
                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Falsches altes Passwort");
                }

            }else if(counter==3) {
                if(user.getPasswort3().equals(str1))
                {
                    if(str.equals(user.getPassword()) || str.equals(user.getPasswort2()) || str.equals(user.getPasswort3())|| str.equals(user.getPasswort4())|| str.equals(user.getPasswort5())|| str.equals(user.getPasswort6()))
                    {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Verwenden Sie nicht die gleichen letzten sechs Passwörter.");}

                    else {
                        user.setPasswort4(str);
                        user.setCounter(4);
                        user.setEdatum(LocalDateTime.now());
                        user.setAdatum(LocalDateTime.now().plusMonths(3));
                        userRepository.save(user);
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Passwort wurde erfolgreich geändert");
                    }
                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Falsches altes Passwort");
                }
            }else if(counter==4) {
                if(user.getPasswort4().equals(str1))
                {
                    if(str.equals(user.getPassword()) || str.equals(user.getPasswort2()) || str.equals(user.getPasswort3())|| str.equals(user.getPasswort4())|| str.equals(user.getPasswort5())|| str.equals(user.getPasswort6()))
                    {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Verwenden Sie nicht die gleichen letzten sechs Passwörter.");}

                    else {
                        user.setPasswort5(str);
                        user.setCounter(5);
                        user.setEdatum(LocalDateTime.now());
                        user.setAdatum(LocalDateTime.now().plusMonths(3));
                        userRepository.save(user);
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Passwort wurde erfolgreich geändert");
                    }
                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Falsches altes Passwort");
                }
            }else if(counter==5) {
                if(user.getPasswort5().equals(str1))
                {
                    if(str.equals(user.getPassword()) || str.equals(user.getPasswort2()) || str.equals(user.getPasswort3())|| str.equals(user.getPasswort4())|| str.equals(user.getPasswort5())|| str.equals(user.getPasswort6()))
                    {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Verwenden Sie nicht die gleichen letzten sechs Passwörter.");}

                    else {
                        user.setPasswort6(str);
                        user.setCounter(6);
                        user.setEdatum(LocalDateTime.now());
                        user.setAdatum(LocalDateTime.now().plusMonths(3));
                        userRepository.save(user);
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Passwort wurde erfolgreich geändert");
                    }
                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Falsches altes Passwort");
                }

            }else  {
                if(user.getPasswort6().equals(str1))
                {
                    if(str.equals(user.getPassword()) || str.equals(user.getPasswort2()) || str.equals(user.getPasswort3())|| str.equals(user.getPasswort4())|| str.equals(user.getPasswort5())|| str.equals(user.getPasswort6()))
                    {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Verwenden Sie nicht die gleichen letzten sechs Passwörter.");}

                    else {
                        user.setPassword(str);
                        user.setCounter(1);
                        user.setEdatum(LocalDateTime.now());
                        user.setAdatum(LocalDateTime.now().plusMonths(3));
                        userRepository.save(user);
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Passwort wurde erfolgreich geändert");
                    }
                }else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Falsches altes Passwort");
                }
            }



        }else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig Benutzername");
        }
    }


    //Wenn Admins auf Button Passwort zurücksetzen für Kundebetreuer  in Kundenbetreuer-Seite Klicken
    @CrossOrigin
    @PostMapping("/updatePassword2")
    public ResponseEntity<String> updatePassword2(@RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String newPassword = credentials.get("password");

        Optional<User> optionalUser = userService.authenticateUser2(username);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            user.setPassword(newPassword);
            user.setPasswortStatus("initialPasswort");
            user.setPasswort2("");
            user.setPasswort3("");
            user.setPasswort4("");
            user.setPasswort5("");
            user.setPasswort6("");
            user.setCounter(0);
            user.setEdatum(LocalDateTime.now());
            user.setAdatum(LocalDateTime.now().plusMonths(3));
            userRepository.save(user);

            return ResponseEntity.ok("update erfolgreich");
        } else {
            // Authentication failed
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("ungültig Benutzername oder passwort");
        }
    }
}
