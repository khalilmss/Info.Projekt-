package com.crminfo.crminfo.service;
import java.util.List;
import com.crminfo.crminfo.entity.Bezirk;


public interface BezirkService {
    List<Bezirk> findAll();
    Bezirk findById(Long id);
    Bezirk save(Bezirk bezirk);
    void deleteById(Long id);

}
