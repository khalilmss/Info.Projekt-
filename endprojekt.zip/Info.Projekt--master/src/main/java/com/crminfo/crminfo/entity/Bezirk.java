package com.crminfo.crminfo.entity;
import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;




@Entity
@Table(name = "bezirk")
public class Bezirk {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @OneToMany(mappedBy = "bezirk", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Filiale> filialen = new HashSet<>();

    // Constructors, Getters and Setters
}