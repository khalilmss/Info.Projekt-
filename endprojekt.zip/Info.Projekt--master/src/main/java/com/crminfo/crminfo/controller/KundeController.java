package com.crminfo.crminfo.controller;

import com.crminfo.crminfo.entity.EmailVersand;
import com.crminfo.crminfo.entity.Kunde;
import com.crminfo.crminfo.service.EmailService;
import com.crminfo.crminfo.service.KundeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import  com.crminfo.crminfo.entity.Bezirk;
import  com.crminfo.crminfo.service.BezirkService;
@RestController
@RequestMapping("/kunde")
public class KundeController {

    public boolean isBirthdayExactly5DaysAway(LocalDate userBirthday) {
        if (userBirthday == null) {
            return false;
        }

        LocalDate today = LocalDate.now();
        LocalDate birthdayThisYear = LocalDate.of(today.getYear(), userBirthday.getMonth(), userBirthday.getDayOfMonth());

        // If the birthday has already occurred this year, set it for the next year
        if (birthdayThisYear.isBefore(today)) {
            birthdayThisYear = birthdayThisYear.plusYears(1);
        }

        long daysUntilBirthday = ChronoUnit.DAYS.between(today, birthdayThisYear);

        // Check if the birthday is exactly 5 days away
        return daysUntilBirthday == 5;
    }

    private final KundeService kundeService;
    //private KundenService kundenService;

    //private EntityManager entityManager;

    public KundeController(KundeService kundeService) {
        this.kundeService = kundeService;
    }
/*#khalilCode*/

    //Read all Kunden
   @GetMapping("/all")
    public ResponseEntity<List<Kunde>> getAllKunde() {
        List<Kunde> allKunde = kundeService.findAll();
        //List<Kunden> kundenList = kundenService.findAll();
        return ResponseEntity.ok(allKunde);
        //return new ResponseEntity<>(kundenList, HttpStatus.OK);
    }
    @PostMapping("/check-email")
    public ResponseEntity<?> checkEmail(@RequestBody Kunde kunde) {
        boolean emailExists = kundeService.emailExists(kunde.getEmail());
        if(emailExists) {
            return ResponseEntity.ok(Map.of("exists", true));
        } else {
            return ResponseEntity.ok(Map.of("exists", false));
        }
    }


@GetMapping("/db")
public List<Kunde> Birthday() {
    List<Kunde> all = kundeService.findAll();
    List<Kunde> upcomingBirthdays = new ArrayList<>();


    for (Kunde k : all) {
        if (isBirthdayExactly5DaysAway(k.getGeburtsdatum())) {
            upcomingBirthdays.add(k);
        }
    }

    // Optional: Print emails of customers with upcoming birthdays
    upcomingBirthdays.forEach(k -> System.out.println(k.getEmail()));

    return upcomingBirthdays;
}
    @PutMapping("/{id}/emailSentForBirthday")
    public ResponseEntity<?> setEmailSentForBirthday(@PathVariable Long id, @RequestBody Map<String, Boolean> update) {
        boolean sentStatus = update.getOrDefault("sentStatus", false);
        kundeService.setEmailSentForBirthday(id, sentStatus);
        return ResponseEntity.ok().build();
    }
   /* @GetMapping("/all")
    //public String all_kunde(Model theModel){
    public List<Kunden> all_kunde(Model theModel){
        System.out.println("testtttttttttttt");
        Kunden all1 = kundenService.findById(1);
        List<Kunden> all = kundenService.findAll();
        createkundenwithcomment(kundenService);
//      System.out.println(all.getKontakt_history());

//        System.out.println(all.getKontakt_history().get(1));
        System.out.println(all1.getfamilienstatus());
        System.out.println(all1.getFirst_name());
        System.out.println(all1.getLast_name());
        System.out.println(all1.getGeburtsdatum());
        System.out.println(all1.getLast_name());
        System.out.println(all1.getStatsängehörigkeit());
        List<Kontakt_history> kh = all1.getKontakt_history();
        for(Kontakt_history s : kh){
            System.out.println(s.getComment() + "####" + s.getDatum() );
        }   
//
//        System.out.println("jetzt");
//         createkundenwithcomment(kundenService);
//        System.out.println(all.getKontakt_history());
//        kundenService.save(all);
        System.out.println("theeeeeeeeeeeeFetch");
//         retrieveKundenAndComment(kundenService);
//
        theModel.addAttribute("all", all);
                    return  all;
        //        return "employees/list-kunden";
    } */

    //    @{/employees/delete(employeeId=${tempEmployee.id})}
    //Create a new KUnde
    /*@PostMapping
    public ResponseEntity<Kunde> addKunden(@RequestBody Kunde kunden) {
        Kunde newKunden = kundeService.save(kunden);
        return new ResponseEntity<>(newKunden, HttpStatus.CREATED);
       return ResponseEntity.ok(newKunden);

       }*/
    @CrossOrigin(origins = "*")
    @PostMapping("/add")
    public ResponseEntity<Kunde> addKunde(@RequestBody Kunde kunde) {
        Kunde addKunde = kundeService.save(kunde);
        return new ResponseEntity<>(addKunde, HttpStatus.CREATED);

    }



    @CrossOrigin(origins = "*")
    @GetMapping("filiale/{filialeId}")
    public ResponseEntity<List<Kunde>> getKundeByFiliale(@PathVariable Long filialeId) {
        List<Kunde> kundeList = kundeService.findKundenByFiliale(filialeId);
        // Convert to a simpler DTO if necessary to only send name and first name
        return new ResponseEntity<>(kundeList, HttpStatus.OK);}




    @GetMapping("/kunde/{id}")
    public ResponseEntity<Kunde> getKundeById(@PathVariable Long id) {
        Kunde kunde = kundeService.findById(id);
        //return ResponseEntity.ok(kunden);
        return new ResponseEntity<>(kunde, HttpStatus.OK);
    }



    @PutMapping("/{id}")
    public ResponseEntity<Kunde> updateKunde(@PathVariable Long id, @RequestBody Kunde kundenDetails) {
        Kunde existingKunden = kundeService.findById(id);
        if (existingKunden == null) {
            // Handle the case where the Kunde with the specified ID doesn't exist
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Update the existing Kunden with new details from kundenDetails

        existingKunden.setTitel(kundenDetails.getTitel());
        existingKunden.setStrasse(kundenDetails.getStrasse());
        existingKunden.setPlz(kundenDetails.getPlz());
        existingKunden.setOrt(kundenDetails.getOrt());
        existingKunden.setEmail(kundenDetails.getEmail());
        existingKunden.setFamilienstatus(kundenDetails.getFamilienstatus());
        existingKunden.setBerufsgruppe(kundenDetails.getBerufsgruppe());
        existingKunden.setSelbststandig(kundenDetails.getSelbststandig());
        existingKunden.setSelbstandingseit(kundenDetails.getSelbstandingseit());
        existingKunden.setBranche(kundenDetails.getBranche());
        existingKunden.setNetto(kundenDetails.getNetto());
        existingKunden.setAnzahlderKinde(kundenDetails.getAnzahlderKinde());
        existingKunden.setWohnart(kundenDetails.getWohnart());
        existingKunden.setProdukte(kundenDetails.getProdukte());
        existingKunden.setNummerTyp(kundenDetails.getNummerTyp());
        existingKunden.setNummer(kundenDetails.getNummer());
        existingKunden.setKundenStatus(kundenDetails.getKundenStatus());
        existingKunden.setEinverstandenWerbungPerEmail(kundenDetails.isEinverstandenWerbungPerEmail());
        existingKunden.setEinverstandenUebermittlungAnSchufa(kundenDetails.isEinverstandenUebermittlungAnSchufa());

        //

        Kunde updatedKunden = kundeService.save(existingKunden);
        return new ResponseEntity<>(updatedKunden, HttpStatus.OK);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteKunde(@PathVariable Long id) {
        kundeService.deleteById(id);
        //return ResponseEntity.ok("Kunden deleted successfully");
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Autowired
    private EmailService emailService;

    @PostMapping
    public ResponseEntity<String> addOrUpdateKunde(@RequestBody Kunde kunde) {
        try {
            Kunde savedKunde = kundeService.saveOrUpdateKunde(kunde);
            // Assuming saveOrUpdateKunde handles checking consent and sending an email

            return new ResponseEntity<>("Kunde saved/updated successfully", HttpStatus.OK);

        } catch (Exception e) {
            // Log the exception and return an appropriate error response
            return new ResponseEntity<>("Error saving customer: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }}





