package com.crminfo.crminfo.service;
import com.crminfo.crminfo.entity.EmailVersand;

import java.util.List;

public interface EmailVersandService {
    boolean checkKundeExists(String name, String vorname,String email);
    List<EmailVersand> findAllEmails();

    EmailVersand save(EmailVersand emailVersand);


}
