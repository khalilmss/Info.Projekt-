package com.crminfo.crminfo.entity;
import jakarta.persistence.*;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Table(name = "email_versand")
public class EmailVersand {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "kundeName")
    private String kundeName;
    @Column(name = "kundeVorname")
    private String kundeVorname;

    @Column(name = "email")
    private String email;
    @Column(name = "betreff")
    private String betreff;
    @Column(name = "inhalt")
    private String inhalt;

    public EmailVersand(Long id, String kundeName, String kundeVorname, String email, String betreff, String inhalt) {
        this.id = id;
        this.kundeName = kundeName;
        this.kundeVorname = kundeVorname;
        this.email = email;
        this.betreff = betreff;
        this.inhalt = inhalt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getKundeName() {
        return kundeName;
    }

    public void setKundeName(String kundeName) {
        this.kundeName = kundeName;
    }

    public String getKundeVorname() {
        return kundeVorname;
    }

    public void setKundeVorname(String kundeVorname) {
        this.kundeVorname = kundeVorname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBetreff() {
        return betreff;
    }

    public void setBetreff(String betreff) {
        this.betreff = betreff;
    }

    public String getInhalt() {
        return inhalt;
    }

    public void setInhalt(String inhalt) {
        this.inhalt = inhalt;
    }

    @Override
    public String toString() {
        return "EmailVersand{" +
                "id=" + id +
                ", kundeName='" + kundeName + '\'' +
                ", kundeVorname='" + kundeVorname + '\'' +
                ", email='" + email + '\'' +
                ", betreff='" + betreff + '\'' +
                ", inhalt='" + inhalt + '\'' +
                '}';
    }
}
