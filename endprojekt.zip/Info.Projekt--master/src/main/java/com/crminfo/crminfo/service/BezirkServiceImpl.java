package com.crminfo.crminfo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crminfo.crminfo.dao.BezirkRepository;
import com.crminfo.crminfo.entity.Bezirk;

import java.util.List;

@Service
public class BezirkServiceImpl implements BezirkService {

    private final BezirkRepository bezirkRepository;

    @Autowired
    public BezirkServiceImpl(BezirkRepository bezirkRepository) {
        this.bezirkRepository = bezirkRepository;
    }

    @Override
    public List<Bezirk> findAll() {
        return bezirkRepository.findAll();
    }

    @Override
    public Bezirk findById(Long id) {
        return bezirkRepository.findById(id).orElse(null);
    }

    @Override
    public Bezirk save(Bezirk bezirk) {
        return bezirkRepository.save(bezirk);
    }

    @Override
    public void deleteById(Long id) {
        bezirkRepository.deleteById(id);
    }
}
