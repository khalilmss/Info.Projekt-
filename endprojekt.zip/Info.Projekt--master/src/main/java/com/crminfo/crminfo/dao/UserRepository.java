package com.crminfo.crminfo.dao;


import java.util.Optional;

import com.crminfo.crminfo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsernameAndPassword(String username, String password);
    Optional<User> findByUsername(String username);
    Optional<User> findByUsernameAndPasswort2(String username, String passwort2);
    Optional<User> findByUsernameAndPasswort3(String username, String passwort3);
    Optional<User> findByUsernameAndPasswort4(String username, String passwort4);
    Optional<User> findByUsernameAndPasswort5(String username, String passwort5);
    Optional<User> findByUsernameAndPasswort6(String username, String passwort6);


}

