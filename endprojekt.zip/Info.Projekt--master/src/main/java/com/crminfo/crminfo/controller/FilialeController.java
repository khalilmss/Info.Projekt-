package com.crminfo.crminfo.controller;

import com.crminfo.crminfo.service.KundeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.crminfo.crminfo.entity.Filiale;
import com.crminfo.crminfo.service.FilialeService;
import com.crminfo.crminfo.entity.Kunde;

import java.util.List;

@RestController
@RequestMapping("/api/filialen")
public class FilialeController {

    private final FilialeService filialeService;

    @Autowired
    public FilialeController(FilialeService filialeService) {
        this.filialeService = filialeService;
    }

   /* @GetMapping
    public List<Filiale> getAllFilialen() {
        return filialeService.findAll();
    }*/
   @GetMapping("/all")
   public ResponseEntity<List<Filiale>> getAllFilialen() {
       List<Filiale> filialen = filialeService.findAll();
       return ResponseEntity.ok(filialen);
   }

    @GetMapping("/{id}")
    public ResponseEntity<Filiale> getFilialeById(@PathVariable Long id) {
        Filiale filiale = filialeService.findById(id);
        if (filiale == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(filiale);
    }
    @GetMapping("/filialen/{bezirkId}")
    public ResponseEntity<List<Filiale>> getFilialenByBezirk(@PathVariable Long bezirkId) {
        List<Filiale> filialen = filialeService.findByBezirkId(bezirkId);
        return ResponseEntity.ok(filialen);
    }

   /* @PostMapping
    public Filiale createFiliale(@RequestBody Filiale filiale) {
        return filialeService.save(filiale);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Filiale> updateFiliale(@PathVariable Long id, @RequestBody Filiale filialeDetails) {
        Filiale filiale = filialeService.findById(id);
        if (filiale == null) {
            return ResponseEntity.notFound().build();
        }
        // Update properties of filiale
        return ResponseEntity.ok(filialeService.save(filiale));
    }

    /*@DeleteMapping("/{id}")
    public ResponseEntity<?> deleteFiliale(@PathVariable Long id) {
        if (filialeService.findById(id) == null) {
            return ResponseEntity.notFound().build();
        }
        filialeService.deleteById(id);
        return ResponseEntity.ok().build();
    }*/
}

