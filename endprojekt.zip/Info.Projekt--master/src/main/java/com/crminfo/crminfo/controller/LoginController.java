package com.crminfo.crminfo.controller;

/*import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

    @GetMapping("/showMyLoginPage")
    public String showMyLoginPage(){

//        return "employees/plain-login";
        return "employees/fancy-login";
    }

    //add request mapping for /acces-denied
    @GetMapping("/access-denied")
    public String showAccessDenied(){

        return "employees/access-denied";
    }
}*/
import com.crminfo.crminfo.entity.LoginRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;


@RestController
public class LoginController {

    // Example of in-memory user storage for simplicity
    // WARNING: This is for demonstration purposes only!
    private Map<String, String> users = new HashMap<>();

    public LoginController() {
        // Hardcoded user credentials (username:password)
        users.put("Ahmed", "123456");
        users.put("user2", "123456");
    }

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
        String username = loginRequest.getUsername();
        String password = loginRequest.getPassword();

        if (users.containsKey(username) && users.get(username).equals(password)) {
            return ResponseEntity.ok().body("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }
}

