package com.crminfo.crminfo.service;
import java.util.List;
import com.crminfo.crminfo.entity.Filiale;

public interface FilialeService {
    List<Filiale> findAll();
    Filiale findById(Long id);
    Filiale save(Filiale filiale);
    void deleteById(Long id);

    List<Filiale> findByBezirkId(Long bezirkId);



}


