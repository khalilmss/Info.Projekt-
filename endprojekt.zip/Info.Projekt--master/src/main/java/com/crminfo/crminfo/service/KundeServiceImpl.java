package com.crminfo.crminfo.service;
import com.crminfo.crminfo.dao.KundeRepository;
import com.crminfo.crminfo.entity.Kunde;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class KundeServiceImpl implements KundeService {

    private final KundeRepository kundeRepository;
    private final EntityManager entityManager;

    @Autowired
    private EmailService emailService;
    //KundenRepository kundenRepository;

    //EntityManager entityManager;
    @Autowired
    public KundeServiceImpl(KundeRepository kundeRepository, EntityManager entityManager) {
        this.kundeRepository = kundeRepository;
        this.entityManager = entityManager;
    }
    @Override
    public List<Kunde> findKundenByFiliale(Long filialeId) {
        // Assuming you have a method in your repository to find by Filiale
        return kundeRepository.findByFilialeId(filialeId);}



    @Override
    public List<Kunde> findAll() {
        return kundeRepository.findAll();
    }

    @Override
    public Kunde findById(Long theId) {
        /*Optional<Kunden> result = kundenRepository.findById(theId);

        Kunden theKunden = null;

        if (result.isPresent()) {
            theKunden = result.get();
        }
        else {
            // we didn't find the Kunden
            throw new RuntimeException("Did not find employee id - " + theId);

        }

        return theKunden;*/
        //(Kunde)
        return  kundeRepository.findById(theId)
                .orElseThrow(() -> new RuntimeException("Kunden not found with id - " + theId));

    }

    @Override
    //@Transactional
    public Kunde save(Kunde theKunden) {
        return kundeRepository.save(theKunden);
    }
    /*public Kunden save(Kunden theEmployee) {
        return kundenRepository.save(theEmployee);
    }*/

    @Override
    public void deleteById(Long theId) {
        kundeRepository.deleteById(theId);
    }

    @Override
    public Kunde saveOrUpdateKunde(Kunde kunde) {
        // Determine if it's an add or update operation
        boolean isNewAddition = kunde.getId() == null;

        // Save or update the Kunde object in the database
        Kunde savedKunde = kundeRepository.save(kunde);

        // Check if the customer has consented to receive marketing emails
        if (savedKunde.isEinverstandenWerbungPerEmail()) {
            // Check if an email address is provided and not empty
            if (savedKunde.getEmail() != null && !savedKunde.getEmail().isEmpty()) {
                // Further check if it's a new addition or if the email was updated
                if (isNewAddition || emailChanged(savedKunde)) {
                    String emailContent = String.format(
                            "Sehr geehrte(r) %s %s,\n\n" +
                                    "wir möchten uns herzlich bedanken, dass Sie sich dafür entschieden haben, Werbung von uns zu erhalten. " +
                                    "Wir freuen uns, Sie über Neuigkeiten, Angebote und Aktionen auf dem Laufenden halten zu dürfen.\n\n" +
                                    "Mit freundlichen Grüßen,\nIhr Team von [Ihr Unternehmen]",

                            savedKunde.getVorname(), // First placeholder %s
                            savedKunde.getName() // Second placeholder %s
                    );

                    // Send the marketing email
                    emailService.sendMarketingEmail(savedKunde.getEmail(),
                            "Bestätigung Ihrer Anmeldung für Werbung",
                            emailContent);
                }
            } else {
                // Log or handle the absence of an email address
                System.out.println("Keine E-Mail-Adresse für den Kunden mit der ID: " + savedKunde.getId() + " angegeben.");
            }
        }
        return savedKunde;
    }
    @Override
    public boolean emailExists(String email) {
        return kundeRepository.existsByEmail(email);
    }


    private boolean emailChanged(Kunde updatedKunde) {
        // Check if the Kunde has an ID, indicating it's an update operation
        if (updatedKunde.getId() != null) {
            // Fetch the current state of the Kunde from the database
            Optional<Kunde> currentKundeOptional = kundeRepository.findById(updatedKunde.getId());

            if (currentKundeOptional.isPresent()) {
                Kunde currentKunde = currentKundeOptional.get();
                // Compare the current email with the updated email
                return !Objects.equals(currentKunde.getEmail(), updatedKunde.getEmail());
            }
        }
        // If the Kunde is new or not found, consider the email hasn't changed
        // Or handle this case differently if needed
        return false;
    }
    /*public void setEmailSentForBirthday(Long id, boolean sentStatus) {
        Kunde kunde = kundeRepository.findById(id).orElseThrow(() -> new RuntimeException("Kunde not found"));
        kunde.setEmailSentForBirthday(sentStatus);
        kundeRepository.save(kunde);
    }*/
    @Transactional
    public void setEmailSentForBirthday(Long id, boolean sentStatus) {
        Kunde kunde = kundeRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Kunde not found with id: " + id));
        kunde.setEmailSentForBirthday(sentStatus);
        kundeRepository.save(kunde);
    }

    /*@Override
    @Transactional
    public void savek(Kunden thekunden) {
        entityManager.persist(thekunden);
    }*/

    /*@Override
    public Kunde findKundenAndCommentByKundenId(int theId) {

        TypedQuery<Kunde> query = entityManager.createQuery(
                "SELECT c from Kunde c "
                        + "JOIN FETCH c.kontakt_history "
                        + "where c.Id = :data", Kunde.class);

        query.setParameter("data", theId);

        // execute query
        Kunde theKunden = query.getSingleResult();
        return theKunden;
    }*/
}
