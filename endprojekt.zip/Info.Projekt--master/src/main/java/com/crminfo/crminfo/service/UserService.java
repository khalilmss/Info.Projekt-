package com.crminfo.crminfo.service;


import java.time.LocalDateTime;
import java.util.Optional;

import com.crminfo.crminfo.dao.UserRepository;
import com.crminfo.crminfo.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }



    public Optional<User> authenticateUser1(String username, String password) {
        return userRepository.findByUsernameAndPassword(username,password);
    }

    public Optional<User> authenticateUser2(String username) {
        return userRepository.findByUsername(username);
    }

    public Optional<User> authenticateUser3(String username, String passwort2) {
        return userRepository.findByUsernameAndPasswort2(username,passwort2);

    }
    public Optional<User> authenticateUser4(String username, String passwort3) {
        return userRepository.findByUsernameAndPasswort3(username,passwort3);

    }
    public Optional<User> authenticateUser5(String username, String passwort4) {
        return userRepository.findByUsernameAndPasswort4(username,passwort4);

    }
    public Optional<User> authenticateUser6(String username, String passwort5) {
        return userRepository.findByUsernameAndPasswort5(username,passwort5);

    }
    public Optional<User> authenticateUser7(String username, String passwort6) {
        return userRepository.findByUsernameAndPasswort6(username,passwort6);

    }










    public void updateUserStatus(Long userId,String newStatus) {
        userRepository.findById(userId).ifPresent(user -> {
            user.setStatus(newStatus);
            user.setEdatum(LocalDateTime.now());
            user.setAdatum(LocalDateTime.now().plusMonths(3));
            userRepository.save(user);
        });
    }

    public void rejectUserStatus(Long userId,String newStatus) {
        userRepository.findById(userId).ifPresent(user -> {
            user.setStatus(newStatus);
            userRepository.save(user);
        });
    }


    public void updateUserStatus2(Long userId,String newStatus) {
        userRepository.findById(userId).ifPresent(user -> {
            user.setStatus(newStatus);
            user.setAdmin("admin1");
            userRepository.save(user);
        });
    }


    public void updateUserStatus3(Long userId,String newStatus) {
        userRepository.findById(userId).ifPresent(user -> {
            user.setStatus(newStatus);
            user.setAdmin("admin2");
            userRepository.save(user);
        });
    }


    public void deleteUser(Long userId) {
        userRepository.findById(userId).ifPresent(user -> {

            userRepository.delete(user);
        });
    }



}

