package com.crminfo.crminfo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.NoArgsConstructor;
import jakarta.persistence.Entity;

import java.time.LocalDate;
@Entity
@NoArgsConstructor
@Table(name = "kontakt_entry")
public class KontaktEntry {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;

    @Column(name = "filialeName")
    private String filialeName;


    @Column(name="filialeId")
    private Long filialeId;
    @Column(name = "kundeName")
    private String kundeName;
    @Column(name = "kundeVorname")
    private String kundeVorname;
    private LocalDate date;
    @Column(name = "activityType")
    private String activityType;
    @Column(name = "initiator")
    private String initiator;
    @Column(name = "customerNeeds")
    private String customerNeeds;
    @Column(name = "angebot")
    private String angebot;
    private boolean acceptance;

    @Column(name = "rejectionReason")
    private String rejectionReason;




    public KontaktEntry(Long id, String filialeName, Long filialeId,String kundeName, String kundeVorname, LocalDate date, String activityType,String initiator ,String customerNeeds,String angebot ,boolean acceptance, String rejectionReason) {
        this.id = id;
        this.filialeName = filialeName;
        this.filialeId =filialeId;
        this.kundeName = kundeName;
        this.kundeVorname = kundeVorname;
        this.date = date;
        this.activityType = activityType;
        this.initiator=initiator;
        this.customerNeeds = customerNeeds;
        this.angebot=angebot;
        this.acceptance = acceptance;
        this.rejectionReason = rejectionReason;


    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }



    public String getFilialeName() {
        return filialeName;
    }

    public void setFilialeName(String filialeName) {
        this.filialeName = filialeName;
    }

    public Long getfilialeId() {
        return filialeId;
    }

    public void setfilialeId(Long filialeId) {
        this.id = filialeId;
    }

    public String getKundeName() {
        return kundeName;
    }

    public void setKundeName(String kundeName) {
        this.kundeName = kundeName;
    }

    public String getKundeVorname() {
        return kundeVorname;
    }

    public void setKundeVorname(String kundeVorname) {
        this.kundeVorname = kundeVorname;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getInitiator() {
        return initiator;
    }

    public void setInitiator(String initiator) {
        this.initiator = initiator;
    }

    public String getCustomerNeeds() {
        return customerNeeds;
    }

    public void setCustomerNeeds(String customerNeeds) {
        this.customerNeeds = customerNeeds;
    }

    public String getAngebot() {
        return angebot;
    }

    public void setAngebot(String angebot) {
        this.angebot = angebot;
    }

    public boolean isAcceptance() {
        return acceptance;
    }

    public void setAcceptance(boolean acceptance) {
        this.acceptance = acceptance;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    

    @Override
    public String toString() {
        return "KontaktEntry{" +
                "id=" + id +
                ", filialeName='" + filialeName + '\'' +
                "filialeId=" + filialeId +
                ", kundeName='" + kundeName + '\'' +
                ", kundeVorname='" + kundeVorname + '\'' +
                ", date=" + date +
                ", activityType='" + activityType + '\'' +
                ", initiator='" + initiator + '\'' +
                ", customerNeeds='" + customerNeeds + '\'' +
                ", angebot='" + angebot + '\'' +
                ", acceptance=" + acceptance +
                ", rejectionReason='" + rejectionReason + '\'' +

                '}';
    }
}
