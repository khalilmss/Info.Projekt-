package com.crminfo.crminfo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.crminfo.crminfo.entity.Bezirk;
import com.crminfo.crminfo.service.BezirkService;


import java.util.List;

@RestController
@RequestMapping("/api/bezirke")
public class BezirkController {

    private final BezirkService bezirkService;

    @Autowired
    public BezirkController(BezirkService bezirkService) {
        this.bezirkService = bezirkService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<Bezirk>> getAllBezirke() {
        List<Bezirk> bezirke = bezirkService.findAll();
        return ResponseEntity.ok(bezirke);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Bezirk> getBezirkById(@PathVariable Long id) {
        Bezirk bezirk = bezirkService.findById(id);
        if (bezirk == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(bezirk);
    }

   /* @PostMapping
    public Bezirk createBezirk(@RequestBody Bezirk bezirk) {
        return bezirkService.save(bezirk);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Bezirk> updateBezirk(@PathVariable Long id, @RequestBody Bezirk bezirkDetails) {
        Bezirk bezirk = bezirkService.findById(id);
        if (bezirk == null) {
            return ResponseEntity.notFound().build();
        }
        // Update properties of bezirk
        return ResponseEntity.ok(bezirkService.save(bezirk));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBezirk(@PathVariable Long id) {
        if (bezirkService.findById(id) == null) {
            return ResponseEntity.notFound().build();
        }
        bezirkService.deleteById(id);
        return ResponseEntity.ok().build();
    }*/
}

