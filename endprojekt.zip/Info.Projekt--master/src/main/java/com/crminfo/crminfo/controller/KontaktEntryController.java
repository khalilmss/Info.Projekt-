package com.crminfo.crminfo.controller;

import com.crminfo.crminfo.entity.KontaktEntry;
import com.crminfo.crminfo.service.KontaktEntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.crminfo.crminfo.dto.KundeInFilialeCheckRequest;
@RestController
@RequestMapping("/api/kontaktentries")
public class KontaktEntryController {

    private final KontaktEntryService kontaktEntryService;

    @Autowired
    public KontaktEntryController(KontaktEntryService kontaktEntryService) {
        this.kontaktEntryService = kontaktEntryService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public KontaktEntry createKontaktEntry(@RequestBody KontaktEntry kontaktEntry) {
        return kontaktEntryService.save(kontaktEntry);
    }

    @GetMapping
    public ResponseEntity<List<KontaktEntry>> getAllKontaktEntries() {
        List<KontaktEntry> entries = kontaktEntryService.findAll();
        return ResponseEntity.ok(entries);
    }
    @PostMapping("/check-kunde-in-filiale")
    public ResponseEntity<?> checkKundeInFiliale(@RequestBody KundeInFilialeCheckRequest request) {
        boolean kundeExists = kontaktEntryService.checkKundeExistsInFiliale(
                request.getName(), request.getVorname(), request.getFilialeId()
        );

        if (kundeExists) {
            // The Kunde exists, so it's okay to proceed with adding the KontaktHistory.
            return ResponseEntity.ok(Map.of("exists", true));
        } else {
            // The Kunde does not exist, indicating the KontaktHistory cannot be added.
            return ResponseEntity.ok(Map.of("exists", false, "message", "Kunde not found in the specified Filiale."));
        }
    }


}